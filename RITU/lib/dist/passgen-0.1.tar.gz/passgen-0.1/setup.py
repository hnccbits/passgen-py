from setuptools import setup
setup(name="passgen",version="0.1",
description="password generator",
long_description="This is a cli based password generator which generates random password",
author="Ritu",packages=["passgen"],install_requires=[])