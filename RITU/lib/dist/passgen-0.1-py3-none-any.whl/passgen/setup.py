from setuptools import setup
setup(name="passgen",version="0.1",
description="this is a CLI_TOOL for random password generator",
author="Ritu",packages=["passgen"],install_requires=[])